SCRIPT INTEGRATO: PULIZIA + CLASSIFICAZIONE 30 + AGGREGAZIONE 10
Input JSON: output\json\merged\all_risultati_enriched_2.4.json
Tabella aggregazione: aggregazioni\load_reference_table_30_to_10.json
Numero classi sorgente (30): 30
Numero classi aggregate finali (10): 10
Record elaborati: 1051
Soggetti unici: 962
Soggetti validi localizzati: 914

Output principali:
- soggetti_puliti_per_record.csv
- soggetti_unici_puliti.csv
- soggetti_unici_classificazione_30.csv
- soggetti_unici_classificazione_10.csv
- attori_regionali_classificazione_30.csv
- attori_regionali_classificazione_10.csv
- attori_macro_classificazione_30.csv
- attori_macro_classificazione_10.csv
- report_sintetico.txt
- report_strutturato.json